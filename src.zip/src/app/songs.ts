import { song } from './songInfo';

export const SONGS: song[] = [
    {sName:'gods plan', artist:'Drake',picture:'assets/images/drake.jpg',genre:'Pop music, Trap music, Pop-rap',YReleased:2018},
    {sName:'Bags', artist:'Clairo',picture:'assets/images/Bags.jpg',genre:'Alternative/Indie',YReleased:2019},
    {sName:'Hotline Bling', artist:'Drake',picture:'assets/images/HotlineBling.jpg',genre:' Pop music, Contemporary R&B',YReleased:2016},
    {sName:'In My Feelings', artist:'Drake',picture:'assets/images/inMyFeelings.jpg',genre:'Hip-Hop/Rap',YReleased:2018}

]