export class kaamanat {
    sid: number;
    name: string;
    login: string;
    campus: string;
    assigTitle: string;
}