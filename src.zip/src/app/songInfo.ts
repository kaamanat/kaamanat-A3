export class song{
    sName: string;
    artist: string;
    picture: string;
    genre: string;
    YReleased: number;
}